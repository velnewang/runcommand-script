#/bin/sh

cat >> ~/.profile << EOS

source ~/.profile.d/_profile.d.sh

EOS
