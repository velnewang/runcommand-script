#/bin/sh

cp -r profile.d/. ~/.profile.d/
