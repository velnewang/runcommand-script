#/bin/sh

# sh ps1.
source ~/.profile.d/sh-prompt_2rows.sh

# sh ps1, with git prompt.
# uri: git/git/contrib/completion/git-prompt.sh
# source ~/.profile.d/sh-prompt-2rows_git.sh
