#/bin/sh

# utility alias.
# alias ls='ls --color=auto --show-control-chars'
alias ls='ls --color=auto'
alias ll='ls -l'
alias lla='ls -Al'
alias llh='ll -h'
alias llah='lla -h'
alias grep='grep --color=auto'
alias rm='rm -i'
alias cp='cp -i'
alias mv='mv -i'
