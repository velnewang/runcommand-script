#/bin/sh

source ~/.profile.d/utility-alias.sh

source ~/.profile.d/sh-ps1.sh
