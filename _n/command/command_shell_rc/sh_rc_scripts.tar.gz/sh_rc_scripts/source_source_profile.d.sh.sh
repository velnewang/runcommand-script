#/bin/sh

source ~/.profile.d/_profile.d.sh
